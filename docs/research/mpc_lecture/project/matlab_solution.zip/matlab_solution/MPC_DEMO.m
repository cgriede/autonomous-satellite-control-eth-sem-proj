%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (c) 2024, Amon Lahr, Simon Muntwiler, Antoine Leeman & Fabian Flürenbrock Institute for Dynamic Systems and Control, ETH Zurich.
%
% All rights reserved.
%
% Please see the LICENSE file that has been included as part of this package.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

classdef MPC_DEMO
    properties
        yalmip_optimizer
    end

    methods
        function obj = MPC_DEMO(params)
            
            A = params.model.A;
            B = params.model.B;

            nx = params.model.nx;
            nu = params.model.nu;
            
            H_x = params.constraints.StateMatrix;
            h_x = params.constraints.StateRHS;
            H_u = params.constraints.InputMatrix;
            h_u = params.constraints.InputRHS;

            N_MPC = params.model.MPCHorizon; % MPC horizon length

            U = sdpvar(repmat(nu,1,N_MPC),ones(1,N_MPC),'full');
            X = sdpvar(repmat(nx,1,N_MPC+1),ones(1,N_MPC+1),'full');
            X0 = sdpvar(nx,1,'full');
            objective = 0;
            constraints = X{1} == X0;
            for k = 1:N_MPC
                constraints = [ ...
                    constraints, ...
                    X{k+1} == A*X{k} + B*U{k} , ...
                    H_x * X{k} <= h_x, ...
                    H_u * U{k} <= h_u ...
                ];

                objective = objective + X{k}'*X{k} + U{k}'*U{k};
            end
            % terminal constraint
            constraints = [ ...
                constraints, ...
                X{N_MPC+1} == zeros(nx,1)
            ];

            opts = sdpsettings('verbose',1,'solver','quadprog');
            obj.yalmip_optimizer = optimizer(constraints,objective,opts,X0,{U{1} objective});
        end

        function [u, u_info] = eval(obj,x)
            %% evaluate control action by solving MPC problem, e.g.
            [optimizer_out,errorcode] = obj.yalmip_optimizer(x);
            [u, objective] = optimizer_out{:};

            feasible = true;
            if (errorcode ~= 0)
                feasible = false;
            end

            u_info = struct('ctrl_feas',feasible,'objective',objective);
        end
    end
end